# MAD-1_final
To use the application follow the given steps:

 1. Create a python virtual env in a terminal using the "python -m venv app" command
 2. Activate the virtual env by command "{location of env}/Scripts/Activate/ps1" 
 3. Install all the required libraries using "pip install -r requirements.txt"
 4. Run the main.py in the terminal
 5. Click on the link rendered in the terminal
